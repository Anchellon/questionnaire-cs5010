package questions;

public interface Question extends Comparable {
    public String getText();
    public String answer(String answer);

}
