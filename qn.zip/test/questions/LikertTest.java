package questions;

import static org.junit.Assert.*;

public class LikertTest {

}